package com.example.minebratassesment.model;

public class GitHubUser {
    public String login;
    public String avatar_url;
    public String name;
    public String bio;
    public int public_repos;
}
