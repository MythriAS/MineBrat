package com.example.minebratassesment.model;

public class Repo {
    public String name;
}